@extends('layouts.app')
@section('title', 'Absensi')

@section('content')
@php $staff = auth()->user()->isStaff(); @endphp

    <x-page-header icon="bi-person-check" :title="$staff ? 'Absensi Pengunjung' : 'Riwayat Absensi'"
        :subtitle="$staff ? 'Catat dan pantau kehadiran anggota di perpustakaan.' : 'Riwayat kehadiranmu di perpustakaan.'" />


    <div class="table-wrap">
        <table class="tbl">
            <thead><tr>@if ($staff)<th>Anggota</th>@endif<th>Tanggal</th><th>Waktu Masuk</th></tr></thead>
            <tbody>
                @forelse ($absensi as $a)
                    <tr>
                        @if ($staff)<td><x-user-cell :user="$a->user" :sub="($a->user->nim_nip ?? '').' · '.ucfirst((string) ($a->user->role ?? ''))" /></td>@endif
                        <td class="whitespace-nowrap">{{ optional($a->tanggal)->translatedFormat('l, d M Y') ?? '-' }}</td>
                        <td class="whitespace-nowrap text-stone-600"><i class="bi bi-clock mr-1 text-stone-400"></i>{{ $a->waktu_masuk ? substr($a->waktu_masuk, 0, 5) : '-' }}</td>
                    </tr>
                @empty
                    <x-empty-state :cols="$staff ? 3 : 2" icon="bi-person-x" title="Belum ada data absensi" text="Kehadiran akan muncul di sini." />
                @endforelse
            </tbody>
        </table>
    </div>

    <div class="mt-4">{{ $absensi->links() }}</div>
@endsection
