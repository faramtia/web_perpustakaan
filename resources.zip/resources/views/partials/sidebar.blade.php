@php
    // Menu sidebar untuk semua role, dikelompokkan seperti template SIAKAD: Master / Transaksi / Layanan / Laporan.
    // Format item: [label, nama route, pola route aktif, ikon, parameter (opsional)]
    $role = auth()->user()->role ?? '';
    $belum = request('tampil') === 'belum';

    $dashboard = [
        'admin' => 'admin.dashboard',
        'petugas' => 'petugas.dashboard',
    ][$role] ?? 'anggota.dashboard';

    $utama = [['Dashboard', $dashboard, $dashboard, 'bi-house-door']];

    if ($role === 'admin') {
        $menu = [
            'Utama' => $utama,
            'Master Data' => [
                ['Data Buku', 'admin.buku.index', 'admin.buku.*', 'bi-book'],
                ['Kategori', 'admin.kategori.index', 'admin.kategori.*', 'bi-grid'],
                ['Lokasi Rak', 'admin.lokasi.index', 'admin.lokasi.*', 'bi-geo-alt'],
                ['Tipe Koleksi', 'admin.tipe-koleksi.index', 'admin.tipe-koleksi.*', 'bi-tags'],
                ['Pengguna', 'admin.pengguna.index', 'admin.pengguna.*', 'bi-people'],
            ],
        ];
    } elseif ($role === 'petugas') {
        $menu = [
            'Utama' => $utama,
            'Master Data' => [
                ['Data Buku', 'admin.buku.index', 'admin.buku.*', 'bi-book'],
            ],
        ];
    } else {
        $menu = [
            'Utama' => $utama,
            'Koleksi' => [
                ['Cari Buku', 'katalog.index', 'katalog.*', 'bi-search'],
                ['Koleksi Tugas Akhir', 'tugas-akhir.index', 'tugas-akhir.*', 'bi-mortarboard'],
            ],
        ];
    }

    if (in_array($role, ['admin', 'petugas'], true)) {
        $menu['Transaksi'] = [
            ['Peminjaman', 'petugas.peminjaman.index', 'petugas.peminjaman.*', 'bi-box-arrow-up-right'],
            ['Pengembalian', 'petugas.peminjaman.index', 'petugas.peminjaman.*', 'bi-arrow-repeat', ['tampil' => 'belum']],
            ['Reservasi', 'petugas.reservasi.index', 'petugas.reservasi.*', 'bi-calendar-check'],
            ['Denda', 'petugas.denda.index', 'petugas.denda.*', 'bi-coin'],
        ];
        $menu['Layanan'] = [
            ['Absensi', 'petugas.absensi.index', 'petugas.absensi.*', 'bi-person-check'],
            ['Kiosk Absensi', 'kiosk.absensi', 'kiosk.*', 'bi-display'],
            ['Feedback', 'petugas.feedback.index', 'petugas.feedback.*', 'bi-chat-dots'],
            ['Tugas Akhir', 'petugas.tugas-akhir.index', 'petugas.tugas-akhir.*', 'bi-mortarboard'],
            ['Event', 'event.index', ['event.*'], 'bi-calendar-event'],
            ['Artikel', 'artikel.index', ['artikel.*', 'admin.artikel.*'], 'bi-newspaper'],
            ['Gallery', 'gallery.index', 'gallery.*', 'bi-images'],
        ];
        $menu['Laporan'] = [
            ['Laporan', 'petugas.laporan.index', 'petugas.laporan.*', 'bi-bar-chart'],
        ];
        if ($role === 'admin') {
            $menu['Laporan'][] = ['Pengaturan', 'admin.setting.index', 'admin.setting.*', 'bi-gear'];
        }
    } else {
        $menu['Transaksi'] = [
            ['Peminjaman Saya', 'anggota.peminjaman.index', 'anggota.peminjaman.*', 'bi-box-arrow-up-right'],
            ['Reservasi Saya', 'anggota.reservasi.index', 'anggota.reservasi.*', 'bi-calendar-check'],
            ['Denda Saya', 'anggota.denda.index', 'anggota.denda.*', 'bi-coin'],
        ];
        $menu['Layanan'] = [
            ['Riwayat Absensi', 'anggota.absensi.index', 'anggota.absensi.*', 'bi-person-check'],
            ['Tugas Akhir', 'anggota.tugas-akhir.index', 'anggota.tugas-akhir.*', 'bi-mortarboard'],
            ['Tanya Pustakawan', 'anggota.feedback.index', 'anggota.feedback.*', 'bi-chat-dots'],
            ['Event Semester', 'event.index', 'event.*', 'bi-calendar-event'],
            ['Artikel', 'artikel.index', 'artikel.*', 'bi-newspaper'],
            ['Gallery', 'gallery.index', 'gallery.*', 'bi-images'],
        ];
    }
@endphp

@php
    $role = auth()->user()->role ?? 'mahasiswa';
@endphp

<aside
    id="sidebar"
    class="w-64 flex-shrink-0 bg-gray-900 text-white flex flex-col fixed lg:static inset-y-0 left-0 z-20 transform -translate-x-full lg:translate-x-0 transition-transform duration-200"
>
    <div class="px-6 py-5 border-b border-gray-700 flex items-center gap-2">
        <img src="{{ asset('images/logo-pnl.png') }}" alt="Logo PNL" class="h-8 w-8 object-contain bg-white rounded-full p-0.5">
        <span class="font-bold text-sm leading-tight">Perpustakaan<br>PNL</span>
    </div>

    <nav class="flex-1 px-3 py-4 space-y-1 text-sm overflow-y-auto">
        @if ($role === 'admin')
            @include('partials.menu-admin')
        @elseif ($role === 'petugas')
            @include('partials.menu-petugas')
        @elseif ($role === 'dosen')
            @include('partials.menu-dosen')
        @else
            @include('partials.menu-mahasiswa')
        @endif
    </nav>

    <div class="px-4 py-4 border-t border-gray-700 text-xs text-gray-400">
        Masuk sebagai <span class="font-semibold capitalize text-gold-400">{{ $role }}</span>
    </div>
</aside>

